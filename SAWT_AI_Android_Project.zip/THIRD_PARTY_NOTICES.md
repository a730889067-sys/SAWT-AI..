# إشعارات التراخيص والأطراف الخارجية

يحتوي APK الناتج عن هذا المشروع على محرك ونماذج صوت محلية. تُنزّل هذه الملفات أثناء بناء APK عبر GitHub Actions وتُضمّن داخل التطبيق.

1. **Sherpa-ONNX 1.13.8** — Apache License 2.0. صفحة المشروع: https://github.com/k2-fsa/sherpa-onnx
2. **Kareem Arabic Piper voice (ar_JO, medium)** — ملفات الصوت من مستودع rhasspy/piper-voices (MIT). نموذج Sherpa-ONNX المحوّل: https://k2-fsa.github.io/sherpa/onnx/tts/all/Arabic/vits-piper-ar_JO-kareem-medium.html
3. **Nabra-82M Arabic MSA voice (af_msa)** — Apache License 2.0 وفق بطاقة النموذج: https://huggingface.co/marwanelamami/nabra-82m-sherpa-onnx
4. **eSpeak NG data** — بيانات النطق المطلوبة لتوليد الفونيمات العربية. المصدر: https://github.com/k2-fsa/sherpa-onnx/releases/tag/tts-models ؛ راجع ترخيص eSpeak NG في المستودع الأصلي: https://github.com/espeak-ng/espeak-ng
5. **ONNX Runtime** — جزء من إصدار Sherpa-ONNX static-linked؛ الترخيص MIT: https://github.com/microsoft/onnxruntime

يرجى الاحتفاظ بهذا الملف مع أي نسخة تعيد توزيعها. لا يعني ترخيص ملفات النموذج أن جميع عناصر التطبيق أو علامته التجارية أصبحت ملكية عامة.
