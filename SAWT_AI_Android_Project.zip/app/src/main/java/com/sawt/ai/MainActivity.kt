package com.sawt.ai

import android.app.Activity
import android.content.res.ColorStateList
import android.graphics.Color
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import com.k2fsa.sherpa.onnx.OfflineTts
import com.k2fsa.sherpa.onnx.OfflineTtsConfig
import com.k2fsa.sherpa.onnx.OfflineTtsKokoroModelConfig
import com.k2fsa.sherpa.onnx.OfflineTtsModelConfig
import com.k2fsa.sherpa.onnx.OfflineTtsVitsModelConfig
import java.io.File
import java.io.IOException
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.max

class MainActivity : Activity() {
    private val bg = Color.rgb(20, 25, 30)
    private val panel = Color.rgb(31, 38, 45)
    private val bubble = Color.rgb(39, 48, 57)
    private val accent = Color.rgb(16, 163, 127)
    private val white = Color.rgb(238, 242, 245)
    private val muted = Color.rgb(160, 172, 181)

    private val worker = Executors.newSingleThreadExecutor()
    private val cancelSpeech = AtomicBoolean(false)
    @Volatile private var currentTrack: AudioTrack? = null
    private var activeTts: OfflineTts? = null
    private var activeVoice: String? = null
    private var busy = false

    private lateinit var chat: LinearLayout
    private lateinit var scroll: ScrollView
    private lateinit var input: EditText
    private lateinit var voicePicker: Spinner
    private lateinit var status: TextView
    private lateinit var speakButton: Button
    private lateinit var stopButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        buildInterface()
        addBubble("أهلاً بك في SAWT AI. اكتب النص، واختر الصوت، ثم اضغط «انطق النص». الأصوات تعمل محلياً بعد تثبيت التطبيق.", false)
    }

    private fun buildInterface() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(14), dp(10), dp(14), dp(10))
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(4), dp(8), dp(4), dp(14))
        }
        val titleBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        titleBox.addView(TextView(this).apply {
            text = "SAWT AI"
            textSize = 23f
            setTextColor(white)
            setTypeface(null, android.graphics.Typeface.BOLD)
        })
        titleBox.addView(TextView(this).apply {
            text = "تحويل النص إلى صوت عربي"
            textSize = 12f
            setTextColor(muted)
        })
        header.addView(titleBox, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        header.addView(TextView(this).apply {
            text = "● يعمل دون إنترنت"
            textSize = 12f
            setTextColor(Color.rgb(91, 210, 164))
            setPadding(dp(10), dp(7), dp(10), dp(7))
            setBackgroundColor(Color.rgb(28, 61, 52))
        })
        root.addView(header)

        scroll = ScrollView(this).apply {
            isFillViewport = true
            clipToPadding = false
            setPadding(0, dp(4), 0, dp(12))
        }
        chat = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        scroll.addView(chat)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        val composer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(12), dp(10), dp(12), dp(10))
            background = rounded(panel, dp(18))
        }
        composer.addView(TextView(this).apply {
            text = "الصوت"
            textSize = 12f
            setTextColor(muted)
        })
        voicePicker = Spinner(this).apply {
            adapter = ArrayAdapter(
                this@MainActivity,
                android.R.layout.simple_spinner_dropdown_item,
                listOf("كريم — صوت رجالي عربي فصيح", "نبرا — صوت نسائي عربي فصيح")
            )
            setSelection(0)
        }
        composer.addView(voicePicker, LinearLayout.LayoutParams(-1, dp(42)))

        input = EditText(this).apply {
            hint = "اكتب أو الصق النص هنا..."
            setHintTextColor(muted)
            setTextColor(white)
            textSize = 17f
            minLines = 3
            maxLines = 6
            gravity = Gravity.TOP or Gravity.RIGHT
            textDirection = View.TEXT_DIRECTION_RTL
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE or android.text.InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
            setPadding(dp(10), dp(10), dp(10), dp(10))
            background = rounded(Color.rgb(24, 30, 36), dp(12))
        }
        val inputParams = LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT)
        inputParams.topMargin = dp(8)
        composer.addView(input, inputParams)

        val buttons = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        speakButton = Button(this).apply {
            text = "انطق النص"
            isAllCaps = false
            setTextColor(Color.WHITE)
            backgroundTintList = ColorStateList.valueOf(accent)
            setOnClickListener { startSpeech() }
        }
        stopButton = Button(this).apply {
            text = "إيقاف الصوت"
            isAllCaps = false
            setTextColor(Color.WHITE)
            backgroundTintList = ColorStateList.valueOf(Color.rgb(135, 55, 62))
            isEnabled = false
            setOnClickListener { stopSpeech() }
        }
        buttons.addView(speakButton, LinearLayout.LayoutParams(0, dp(50), 1f))
        val stopParams = LinearLayout.LayoutParams(0, dp(50), 1f)
        stopParams.marginStart = dp(8)
        buttons.addView(stopButton, stopParams)
        val buttonsParams = LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT)
        buttonsParams.topMargin = dp(8)
        composer.addView(buttons, buttonsParams)
        status = TextView(this).apply {
            text = "الصوتان مدمجان في نسخة APK عند اكتمال البناء."
            textSize = 11f
            setTextColor(muted)
            gravity = Gravity.CENTER
            setPadding(0, dp(8), 0, 0)
        }
        composer.addView(status)
        val noticesLink = TextView(this).apply {
            text = "تراخيص الأصوات ومصادرها"
            textSize = 11f
            setTextColor(Color.rgb(111, 190, 220))
            gravity = Gravity.CENTER
            setPadding(0, dp(7), 0, 0)
            setOnClickListener { showNotices() }
        }
        composer.addView(noticesLink)
        root.addView(composer)
        setContentView(root)
    }

    private fun startSpeech() {
        val value = input.text.toString().trim()
        if (value.isEmpty()) {
            input.error = "اكتب النص أولاً"
            return
        }
        if (value.length > 5000) {
            input.error = "الحد الأقصى 5000 حرف في المرة الواحدة"
            return
        }
        if (busy) return

        val voice = if (voicePicker.selectedItemPosition == 0) "kareem" else "nabra"
        cancelSpeech.set(false)
        busy = true
        speakButton.isEnabled = false
        stopButton.isEnabled = true
        addBubble(value, true)
        updateStatus("يجري تجهيز الصوت محلياً لأول استخدام؛ قد يستغرق ذلك بعض الوقت...")

        worker.execute {
            try {
                val tts = getEngine(voice)
                val completed = streamSpeech(tts, value)
                runOnUiThread {
                    updateStatus(if (completed) "انتهى النطق." else "تم إيقاف النطق.")
                }
            } catch (e: Exception) {
                runOnUiThread {
                    updateStatus("تعذر تشغيل الصوت: ${e.message ?: "خطأ غير معروف"}")
                    addBubble("تعذر تشغيل هذا الصوت. تأكد من اكتمال ملفات النماذج في عملية بناء APK.", false)
                }
            } finally {
                currentTrack?.let { track -> runCatching { track.release() } }
                currentTrack = null
                runOnUiThread {
                    busy = false
                    speakButton.isEnabled = true
                    stopButton.isEnabled = false
                }
            }
        }
    }

    private fun stopSpeech() {
        cancelSpeech.set(true)
        currentTrack?.let { track ->
            runCatching {
                if (track.state == AudioTrack.STATE_INITIALIZED) {
                    track.pause()
                    track.flush()
                }
            }
        }
        updateStatus("طلبت إيقاف الصوت...")
    }

    private fun getEngine(voice: String): OfflineTts {
        if (activeTts != null && activeVoice == voice) return activeTts!!
        activeTts?.release()
        activeTts = null
        activeVoice = null

        val root = File(filesDir, "sawt-models")
        val espeakDir = File(root, "espeak-ng-data")
        if (!espeakDir.exists() || (espeakDir.list()?.isEmpty() != false)) {
            copyAssetTree("models/espeak-ng-data", espeakDir)
        }

        val config = if (voice == "kareem") {
            val dir = File(root, "kareem")
            if (!File(dir, "ar_JO-kareem-medium.onnx").exists()) {
                copyAssetTree("models/kareem", dir)
            }
            OfflineTtsConfig(
                model = OfflineTtsModelConfig(
                    vits = OfflineTtsVitsModelConfig(
                        model = File(dir, "ar_JO-kareem-medium.onnx").absolutePath,
                        tokens = File(dir, "tokens.txt").absolutePath,
                        dataDir = espeakDir.absolutePath
                    ),
                    numThreads = 2,
                    provider = "cpu"
                )
            )
        } else {
            val dir = File(root, "nabra")
            if (!File(dir, "model.int4.onnx").exists()) {
                copyAssetTree("models/nabra", dir)
            }
            OfflineTtsConfig(
                model = OfflineTtsModelConfig(
                    kokoro = OfflineTtsKokoroModelConfig(
                        model = File(dir, "model.int4.onnx").absolutePath,
                        voices = File(dir, "voices.bin").absolutePath,
                        tokens = File(dir, "tokens.txt").absolutePath,
                        dataDir = espeakDir.absolutePath,
                        lang = "ar"
                    ),
                    numThreads = 2,
                    provider = "cpu"
                )
            )
        }
        val engine = OfflineTts(config = config)
        activeTts = engine
        activeVoice = voice
        return engine
    }

    private fun streamSpeech(tts: OfflineTts, text: String): Boolean {
        val sampleRate = tts.sampleRate()
        val minBuffer = AudioTrack.getMinBufferSize(
            sampleRate,
            AudioFormat.CHANNEL_OUT_MONO,
            AudioFormat.ENCODING_PCM_16BIT
        )
        if (minBuffer <= 0) throw IOException("معدل الصوت غير مدعوم")
        val track = AudioTrack(
            AudioManager.STREAM_MUSIC,
            sampleRate,
            AudioFormat.CHANNEL_OUT_MONO,
            AudioFormat.ENCODING_PCM_16BIT,
            max(minBuffer, sampleRate),
            AudioTrack.MODE_STREAM
        )
        if (track.state != AudioTrack.STATE_INITIALIZED) {
            track.release()
            throw IOException("تعذر تشغيل مخرج الصوت")
        }
        currentTrack = track
        track.play()
        var totalFrames = 0L

        for (part in splitText(text)) {
            if (cancelSpeech.get()) break
            tts.generateWithCallback(part, 0, 1.0f) { samples ->
                if (cancelSpeech.get()) {
                    0
                } else {
                    val pcm = ShortArray(samples.size) { index ->
                        (samples[index].coerceIn(-1.0f, 1.0f) * 32767.0f).toInt().toShort()
                    }
                    var offset = 0
                    while (offset < pcm.size && !cancelSpeech.get()) {
                        val count = track.write(pcm, offset, pcm.size - offset)
                        if (count <= 0) break
                        offset += count
                        totalFrames += count
                    }
                    if (cancelSpeech.get() || offset < pcm.size) 0 else 1
                }
            }
        }

        while (!cancelSpeech.get() && track.playState == AudioTrack.PLAYSTATE_PLAYING && track.playbackHeadPosition.toLong() < totalFrames) {
            Thread.sleep(35)
        }
        return !cancelSpeech.get()
    }

    private fun splitText(text: String, maxChars: Int = 220): List<String> {
        val result = mutableListOf<String>()
        var remaining = text.trim()
        while (remaining.isNotEmpty()) {
            if (remaining.length <= maxChars) {
                result.add(remaining)
                break
            }
            var cut = remaining.lastIndexOfAny(charArrayOf('؟', '!', '.', '،', '؛', ' '), maxChars)
            if (cut < maxChars / 2) cut = maxChars
            result.add(remaining.substring(0, cut).trim())
            remaining = remaining.substring(cut).trim()
        }
        return result.filter { it.isNotBlank() }
    }

    private fun copyAssetTree(assetPath: String, destination: File) {
        val children = assets.list(assetPath)
        if (children.isNullOrEmpty()) {
            destination.parentFile?.mkdirs()
            assets.open(assetPath).use { input ->
                destination.outputStream().buffered().use { output -> input.copyTo(output) }
            }
        } else {
            destination.mkdirs()
            children.forEach { child ->
                copyAssetTree("$assetPath/$child", File(destination, child))
            }
        }
    }

    private fun addBubble(message: String, isUser: Boolean) {
        val wrapper = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            gravity = if (isUser) Gravity.END else Gravity.START
            setPadding(dp(4), dp(5), dp(4), dp(5))
        }
        val text = TextView(this).apply {
            this.text = message
            textSize = 16f
            setTextColor(white)
            gravity = Gravity.RIGHT
            textDirection = View.TEXT_DIRECTION_RTL
            setPadding(dp(14), dp(11), dp(14), dp(11))
            background = rounded(if (isUser) Color.rgb(34, 75, 67) else bubble, dp(16))
        }
        val params = LinearLayout.LayoutParams(
            if (isUser) (resources.displayMetrics.widthPixels * 0.82f).toInt() else (resources.displayMetrics.widthPixels * 0.9f).toInt(),
            ViewGroup.LayoutParams.WRAP_CONTENT
        )
        wrapper.addView(text, params)
        chat.addView(wrapper)
        scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
    }

    private fun updateStatus(message: String) {
        runOnUiThread { status.text = message }
    }


    private fun showNotices() {
        val content = try {
            assets.open("THIRD_PARTY_NOTICES.txt").bufferedReader(Charsets.UTF_8).use { it.readText() }
        } catch (_: Exception) {
            "راجع ملف THIRD_PARTY_NOTICES.md المرفق مع مصدر المشروع."
        }
        android.app.AlertDialog.Builder(this)
            .setTitle("تراخيص الأصوات والمكتبات")
            .setMessage(content)
            .setPositiveButton("إغلاق", null)
            .show()
    }

    private fun rounded(color: Int, radius: Int): android.graphics.drawable.GradientDrawable {
        return android.graphics.drawable.GradientDrawable().apply {
            setColor(color)
            cornerRadius = radius.toFloat()
        }
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        cancelSpeech.set(true)
        currentTrack?.let { track -> runCatching { track.pause(); track.flush(); track.release() } }
        worker.shutdownNow()
        super.onDestroy()
    }
}
