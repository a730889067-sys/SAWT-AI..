#!/usr/bin/env bash
set -euo pipefail

PROJECT_DIR="${1:-.}"
PROJECT_DIR="$(cd "$PROJECT_DIR" && pwd)"
APP_DIR="$PROJECT_DIR/app"
ASSETS="$APP_DIR/src/main/assets/models"
WORK="${RUNNER_TEMP:-/tmp}/sawt-ai-model-setup"
mkdir -p "$APP_DIR/libs" "$ASSETS/kareem" "$ASSETS/nabra" "$WORK" "$APP_DIR/src/main/assets"

fetch() {
  local url="$1" out="$2"
  if [[ ! -s "$out" ]]; then
    echo "Downloading: $(basename "$out")"
    curl --fail --location --retry 5 --retry-all-errors --connect-timeout 30 "$url" -o "$out.part"
    mv "$out.part" "$out"
  fi
}

# Sherpa-ONNX 1.13.8 AAR, static-linked with ONNX Runtime.
AAR="$APP_DIR/libs/sherpa-onnx.aar"
fetch "https://sourceforge.net/projects/sherpa-onnx.mirror/files/v1.13.8/sherpa-onnx-static-link-onnxruntime-1.13.8.aar/download" "$AAR"
printf '%s  %s\n' 'b22c3fc1b6a45666d28892bb2f7694beeb77a8362d7ebd77c1a5431ec9435471' "$AAR" | sha256sum --check -
unzip -t "$AAR" >/dev/null

# Male voice: Kareem Arabic (Jordanian MSA), converted by the Sherpa-ONNX project.
KAREEM_TAR="$WORK/kareem.tar.bz2"
fetch "https://github.com/k2-fsa/sherpa-onnx/releases/download/tts-models/vits-piper-ar_JO-kareem-medium.tar.bz2" "$KAREEM_TAR"
mkdir -p "$WORK/kareem-unpacked"
tar -xjf "$KAREEM_TAR" -C "$WORK/kareem-unpacked"
KAREEM_MODEL="$(find "$WORK/kareem-unpacked" -type f -name 'ar_JO-kareem-medium.onnx' -print -quit)"
KAREEM_TOKENS="$(find "$WORK/kareem-unpacked" -type f -name 'tokens.txt' -print -quit)"
test -n "$KAREEM_MODEL" && test -n "$KAREEM_TOKENS"
cp "$KAREEM_MODEL" "$ASSETS/kareem/ar_JO-kareem-medium.onnx"
cp "$KAREEM_TOKENS" "$ASSETS/kareem/tokens.txt"

# Shared eSpeak NG phoneme data required by the offline Arabic voices.
ESPEAK_TAR="$WORK/espeak-ng-data.tar.bz2"
fetch "https://github.com/k2-fsa/sherpa-onnx/releases/download/tts-models/espeak-ng-data.tar.bz2" "$ESPEAK_TAR"
mkdir -p "$WORK/espeak-unpacked"
tar -xjf "$ESPEAK_TAR" -C "$WORK/espeak-unpacked"
ESPEAK_DIR="$(find "$WORK/espeak-unpacked" -type d -name 'espeak-ng-data' -print -quit)"
test -n "$ESPEAK_DIR"
rm -rf "$ASSETS/espeak-ng-data"
cp -a "$ESPEAK_DIR" "$ASSETS/espeak-ng-data"

# Female voice: Nabra-82M, Arabic Modern Standard Arabic (af_msa), Apache-2.0.
fetch "https://huggingface.co/marwanelamami/nabra-82m-sherpa-onnx/resolve/main/model.int4.onnx" "$ASSETS/nabra/model.int4.onnx"
fetch "https://huggingface.co/marwanelamami/nabra-82m-sherpa-onnx/resolve/main/tokens.txt" "$ASSETS/nabra/tokens.txt"
fetch "https://huggingface.co/marwanelamami/nabra-82m-sherpa-onnx/resolve/main/voices.bin" "$ASSETS/nabra/voices.bin"

# Sanity checks catch HTML error pages, truncated model downloads, and missing assets.
test "$(stat -c%s "$ASSETS/kareem/ar_JO-kareem-medium.onnx")" -gt 40000000
test "$(stat -c%s "$ASSETS/nabra/model.int4.onnx")" -gt 40000000
test -s "$ASSETS/kareem/tokens.txt"
test -s "$ASSETS/nabra/tokens.txt"
test -s "$ASSETS/nabra/voices.bin"
test -d "$ASSETS/espeak-ng-data"
test -s "$ASSETS/espeak-ng-data/phondata"

cp "$PROJECT_DIR/THIRD_PARTY_NOTICES.md" "$APP_DIR/src/main/assets/THIRD_PARTY_NOTICES.txt"

echo "SAWT AI offline models prepared."
du -sh "$APP_DIR/libs/sherpa-onnx.aar" "$ASSETS"
